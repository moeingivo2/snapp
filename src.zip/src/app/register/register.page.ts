import { Component, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  IonButton,
  IonContent,
  IonInput,
  IonText,
  NavController,
} from '@ionic/angular';

interface PassengerProfile {
  firstName: string;
  lastName: string;
}

@Component({
  selector: 'app-register',
  imports: [IonContent, IonInput, IonButton, IonText, ReactiveFormsModule],
  template: `
    <ion-content class="ion-padding">
      <div class="register">
        <div class="register-icon">👤</div>

        <h1>تکمیل ثبت‌نام</h1>
        <p class="subtitle">برای شروع، نام و نام خانوادگی‌ات را وارد کن.</p>

        <form [formGroup]="form" (ngSubmit)="submit()">
          <ion-input
            formControlName="firstName"
            label="نام"
            labelPlacement="floating"
            fill="outline"
            autocomplete="given-name"
          ></ion-input>

          @if (form.controls.firstName.invalid && form.controls.firstName.touched) {
            <ion-text color="danger">
              <small>نام باید حداقل دو حرف داشته باشد.</small>
            </ion-text>
          }

          <ion-input
            formControlName="lastName"
            label="نام خانوادگی"
            labelPlacement="floating"
            fill="outline"
            autocomplete="family-name"
          ></ion-input>

          @if (form.controls.lastName.invalid && form.controls.lastName.touched) {
            <ion-text color="danger">
              <small>نام خانوادگی باید حداقل دو حرف داشته باشد.</small>
            </ion-text>
          }

          @if (saveError) {
            <ion-text color="danger">
              <small>ذخیره اطلاعات ممکن نشد. تنظیمات مرورگرت را بررسی کن.</small>
            </ion-text>
          }

          <ion-button expand="block" type="submit">
            تکمیل ثبت‌نام
          </ion-button>
        </form>
      </div>
    </ion-content>
  `,
  styles: [`
    .register {
      display: flex;
      min-height: 100%;
      flex-direction: column;
      justify-content: center;
      gap: 12px;
    }

    .register-icon {
      display: grid;
      place-items: center;
      width: 72px;
      height: 72px;
      margin-bottom: 8px;
      background: rgba(var(--ion-color-primary-rgb), 0.12);
      border-radius: 22px;
      font-size: 36px;
    }

    h1 {
      margin: 0;
      font-weight: 800;
      color: var(--ion-color-primary);
    }

    .subtitle {
      margin: 0 0 16px;
      color: var(--ion-color-medium);
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    ion-button {
      margin-top: 8px;
    }
  `],
})
export class RegisterPage {
  private readonly nav = inject(NavController);

  saveError = false;

  readonly form = new FormGroup({
    firstName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2)],
    }),
    lastName: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2)],
    }),
  });

  submit() {
    const firstName = this.form.controls.firstName.value.trim();
    const lastName = this.form.controls.lastName.value.trim();

    this.form.patchValue({ firstName, lastName });

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const profile: PassengerProfile = { firstName, lastName };

    try {
      localStorage.setItem('snapp_passenger_profile', JSON.stringify(profile));
      this.saveError = false;
      this.nav.navigateRoot('/home');
    } catch {
      this.saveError = true;
    }
  }
}
