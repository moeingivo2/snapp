import {
  HttpErrorResponse,
  HttpEvent,
  HttpInterceptorFn,
  HttpResponse,
} from '@angular/common/http';
import { Observable, map, mergeMap, throwError, timer } from 'rxjs';
import { environment } from '../../environments/environment';
import type { Driver, Place, Ride, RideOption, RideStatus, ServiceType } from './models';

const FAKE_CODE = '12345';
const LATENCY_MS = 800;

const SERVICES: { type: ServiceType; title: string; factor: number }[] = [
  { type: 'eco', title: 'اسنپ اکو', factor: 1 },
  { type: 'plus', title: 'اسنپ پلاس', factor: 1.35 },
  { type: 'bike', title: 'اسنپ موتور', factor: 0.7 },
];

const DRIVER: Omit<Driver, 'position'> = {
  name: 'علی رضایی',
  car: 'پژو ۲۰۶ سفید',
  plate: '۱۲ ب ۳۴۵ - ایران ۷۷',
  rating: 4.8,
};

const rides = new Map<string, { ride: Ride; createdAt: number }>();

function ok(body: unknown): Observable<HttpEvent<unknown>> {
  return timer(LATENCY_MS).pipe(map(() => new HttpResponse({ status: 200, body })));
}

function fail(status: number, error: unknown): Observable<HttpEvent<unknown>> {
  return timer(LATENCY_MS).pipe(
    mergeMap(() => throwError(() => new HttpErrorResponse({ status, error }))),
  );
}

function estimatePrices(distance: number, duration: number): RideOption[] {
  const base = 15000 + (distance / 1000) * 4000 + (duration / 60) * 500;
  return SERVICES.map((service) => ({
    type: service.type,
    title: service.title,
    price: Math.round((base * service.factor) / 500) * 500,
    etaMinutes: 2 + Math.floor(Math.random() * 6),
  }));
}

function statusByTime(createdAt: number): RideStatus {
  const seconds = (Date.now() - createdAt) / 1000;
  if (seconds < 6) return 'searching';
  if (seconds < 16) return 'accepted';
  if (seconds < 22) return 'arrived';
  if (seconds < 40) return 'onboard';
  return 'finished';
}

export const mockInterceptor: HttpInterceptorFn = (req, next) => {
  if (!environment.useMock || !req.url.startsWith(environment.apiUrl)) {
    return next(req);
  }

  const path = req.url.slice(environment.apiUrl.length);
  const key = `${req.method} ${path}`;

  const rideMatch = path.match(/^\/rides\/([\w-]+)(\/cancel)?$/);
  if (rideMatch && path !== '/rides/estimate') {
    const entry = rides.get(rideMatch[1]);
    if (!entry) return fail(404, { message: 'RIDE_NOT_FOUND' });

    if (rideMatch[2] && req.method === 'POST') {
      entry.ride = { ...entry.ride, status: 'cancelled' };
    } else if (entry.ride.status !== 'cancelled') {
      const status = statusByTime(entry.createdAt);
      const driver =
        status === 'searching'
          ? undefined
          : {
              ...DRIVER,
              position: {
                lat: entry.ride.origin.position.lat + 0.003,
                lng: entry.ride.origin.position.lng + 0.003,
              },
            };
      entry.ride = { ...entry.ride, status, driver };
    }
    return ok(entry.ride);
  }

  switch (key) {
    case 'POST /auth/otp':
      return ok({});

    case 'POST /auth/verify': {
      const { phone, code } = req.body as { phone: string; code: string };
      return code === FAKE_CODE
        ? ok({ token: `fake-token-${phone}` })
        : fail(400, { message: 'INVALID_CODE' });
    }

    case 'POST /rides/estimate': {
      const { distance, duration } = req.body as { distance: number; duration: number };
      return ok(estimatePrices(distance, duration));
    }

    case 'POST /rides': {
      const { origin, destination, type } = req.body as {
        origin: Place;
        destination: Place;
        type: ServiceType;
      };
      const service = SERVICES.find((item) => item.type === type) ?? SERVICES[0];
      const ride: Ride = {
        id: crypto.randomUUID(),
        status: 'searching',
        origin,
        destination,
        option: { type: service.type, title: service.title, price: 0, etaMinutes: 0 },
      };
      rides.set(ride.id, { ride, createdAt: Date.now() });
      return ok(ride);
    }

    default:
      console.warn('[MOCK] مسیر تعریف نشده:', key);
      return fail(404, { message: 'MOCK_NOT_FOUND' });
  }
};
