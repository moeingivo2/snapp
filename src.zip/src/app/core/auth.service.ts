import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, map, tap } from 'rxjs';
import { environment } from '../../environments/environment';

const TOKEN_KEY = 'snapp_token';

interface VerifyResponse {
  token: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly token = signal<string | null>(this.readToken());

  readonly accessToken = this.token.asReadonly();
  readonly isLoggedIn = computed(() => this.token() !== null);

  requestOtp(phone: string): Observable<void> {
    return this.http.post<void>(`${environment.apiUrl}/auth/otp`, { phone });
  }

  verifyOtp(phone: string, code: string): Observable<void> {
    return this.http
      .post<VerifyResponse>(`${environment.apiUrl}/auth/verify`, { phone, code })
      .pipe(
        tap((res) => this.saveToken(res.token)),
        map(() => undefined),
      );
  }

  logout(): void {
    this.token.set(null);
    try {
      localStorage.removeItem(TOKEN_KEY);
    } catch {}
  }

  private readToken(): string | null {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }

  private saveToken(value: string): void {
    this.token.set(value);
    try {
      localStorage.setItem(TOKEN_KEY, value);
    } catch {}
  }
}